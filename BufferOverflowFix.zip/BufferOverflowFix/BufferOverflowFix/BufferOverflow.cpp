// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <limits>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  const std::string account_number = "CharlieBrown42";
  char user_input[20];

  std::cout << "Enter a value: ";
  std::cin >> std::setw(20) >> user_input;

  // Check if input failed
  if (std::cin.fail()) {
      std::cin.clear(); // Clear error flags
      std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Flush extra input
      std::cout << "Error: Input was too long or invalid." << std::endl;
  }
  else if (std::cin.peek() != '\n') {
      // Extra characters remain in buffer
      std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
      std::cout << "Warning: Extra characters were ignored to prevent buffer overflow." << std::endl;
  }

  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
